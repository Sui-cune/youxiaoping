// 云函数入口文件
const cloud = require('wx-server-sdk')
let rp = require('request-promise')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  let Token=event.access_token,
      Openid=event.openid

  let url='https://api.weixin.qq.com/wxa/getpaidunionid?access_token='+Token+'&openid='+Openid+''

  return await rp(url)
  .then(function(res){
    return res
  }).then(function(err){
    return err
  })
}