// components/upimg/upimg.js
// import child from "../../pages/feedback/index"
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    path:{
      type:String,
      value:""
    }
  },
  data: {
  },
  methods: {
    remove(){
      let {path}=this.data
      this.triggerEvent('parent', path)
      // console.log(path);
    }
  }
})
