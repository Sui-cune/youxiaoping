
Component({
  properties: {
    values:{
      type:Array,
      value:[]
    }
  },
  data: {
  },
  methods: {
    selected(arr){
      const {index} = arr.currentTarget.dataset
      this.triggerEvent("change",{index})
    }
  }
})
