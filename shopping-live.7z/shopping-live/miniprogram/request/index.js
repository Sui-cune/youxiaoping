// 同时发送异步代码的次数
let ajaxTimes=0;
export let request=(params)=>{
  ajaxTimes++;
  // 显示加载中 效果
  wx.showLoading({
    title: "加载中",
    mask: true
  });
    
  // 定义公共的url
  const baseUrl="https://api-hmugo-web.itheima.net/api/public/v1";
  return new Promise((resolve,reject)=>{
    wx.request({
     ...params,
     url:baseUrl+params.url,
     success:(result)=>{
       resolve(result.data.message);
     },
     fail:(err)=>{
       reject(err);
     },
     complete:()=>{
      ajaxTimes--;
      if(ajaxTimes===0){
        //  关闭正在等待的图标
        wx.hideLoading();
      }
     }
    });
  })
}

export let login=()=>{
    return new Promise((res,rej)=>{
        wx.login({
            timeout:10000,
            success: (result)=>{
                res(result)
            },
            fail: (err)=>{
                rej(err)
            }
        });
    })
}

export let showtoast=(arr)=>{
    return new Promise((res,rej)=>{
        wx.showToast({
            title: arr.title,
            icon: arr.icon||'none',
            image: '',
            duration: 1500,
            mask: arr.mask||false,
            success: (result)=>{
                res(result)
            },
            fail: (err)=>{
                rej(err)
            }
        });
    })
}

export let getuserprofile=()=>{
    return new Promise((res,rej)=>{
        wx.getUserProfile({
            desc: '获取你的昵称、头像、地区及性别',
            success: (result) => {
                wx.setStorageSync('userinfo', result.userInfo);
                res(result.userInfo)
                showtoast({title:'授权成功'})
            },
            fail:(err)=>{
                showtoast({title:"拒绝授权"})
            }
          })
    })
}

export let showModal=({title,content,kong})=>{
    return new Promise((res,rej)=>{
        wx.showModal({
            title:title||'',
            content: content,
            showCancel: true,
            cancelText: '取消',
            cancelColor: '#000000',
            confirmText: '确定',
            confirmColor: '#3CC51F',
            success: (result) => {
                if(result.confirm){
                    if(kong){
                       res(getuserprofile())
                    }else{
                        res(result)
                    }
                }else if(result.cancel){
                    showtoast({title:'取消提示'})
                }
            },
            fail: (err)=>{
                rej(err)
            }
        });
    })
}