// pages/feedback/index.js
import { request, showtoast } from '../../request/index'
Page({
  data: {
    tabs:[
      {
        id:0,
        value:"体验问题",
        active:true
      },
      {
        id:1,
        value:"商品、商家投诉",
        active:false
      }
    ],
    imagepath:[],
    text:""
  },
  // 外网的图片的路径数组
  upimages:[],
  changeselected(arr){
    // console.log(arr)
    //获取被点击项的引索
    const {index}=arr.detail
    let {tabs}=this.data
    tabs.forEach((v,i)=>i==index?v.active=true:v.active=false)
    this.setData({
      tabs
    })
  },
  chooseimg(){
    wx.chooseImage({
      count: 9,
      sizeType: ['original','compressed'],
      // 图片的来源 本地相册 相机
      sourceType: ['album','camera'],
      success: (result)=>{
        // console.log(result);
        this.setData({
          imagepath:[...this.data.imagepath,...result.tempFilePaths]
        })
        // console.log(this.data.imagepath);
      }
    });
  },
  remove(e){
    let path = e.detail,
    {imagepath} = this.data
    let index = imagepath.findIndex(v=>v==path)
    // console.log(index);
    imagepath.splice(index,1)
    this.setData({imagepath})
  },
  textinput(e){
    this.setData({
      text:e.detail.value
    })
  },
  async formsubmit(){
    let {text,imagepath} = this.data
    if(!text.trim()){
      let show = await showtoast({
        title:'输入不合法'
      })
      return
    }
    wx.showLoading({
      title: "正在上传中",
      mask: true
    });

    if(imagepath.length !=0){
      imagepath.forEach((v,i)=>{
          wx.uploadFile({
          url: 'https://img.coolcr.cn/api/upload',
          filePath: v,
          name: "image",
          formData: {},
          success: (result)=>{
            // console.log(result);
            let url=JSON.parse(result.data).data.url
            this.upimages.push(url)
            // console.log(this.upimages);

            // 当所有的图都上传完毕后
            if(i==imagepath.length-1){
              wx.hideLoading();
              // 那么图库连接提交给后台api
              // 图片提交成功后 重置页面
              this.setData({
                text:'',
                imagepath:[]
              })
              wx.navigateBack({
                delta: 1
              });
            }
          }
        });
      })
    }else{
      wx.hideLoading();
      wx.navigateBack({
        delta: 1
      });
      // console.log();
    }
    
  }
})