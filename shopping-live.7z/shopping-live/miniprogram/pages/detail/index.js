// pages/detail.js
import { request, showtoast } from "../../request/index.js";

Page({
  data: {
    goodslist:{},
    iscollect:false
  },
  goodsinfo:{},
  onShow: function () {
    var curPages =  getCurrentPages();
    let page=curPages[curPages.length-1]
    let options=page.options

    let {goods_id} = options
    this.getgoodslist(goods_id)
  },
  history(){
    let history = wx.getStorageSync('history')||[];
    let goodsinfo = [], index=''
    this.goodsinfo.checked=true
    goodsinfo.push(this.goodsinfo)
    history.forEach((v,i)=>{
      let oo =[v].findIndex(v=>{
        if(v.goods_id==goodsinfo[0].goods_id){
          index=i
          if(index!=''){
            history.splice(index,1)
            console.log('1');
            return
          }else if(index=='0'){
            history.splice(0,1)
          }
          return
        }
      })
    })
    history = [...goodsinfo,...history]
    wx.setStorageSync('history', history);
  },
  async getgoodslist(goods_id){
    let res = await request({
      url:"/goods/detail",
      data:{goods_id}
    })
    this.goodsinfo=res
    let collect=wx.getStorageSync("collect")||[];
    let iscollect=collect.some(v=>v.goods_id==this.goodsinfo.goods_id)

    this.setData({
      goodslist:{
        goods_name:res.goods_name,
        goods_price:res.goods_price,
        // 因为introduce里的图片是webp格式 部分iphone不识别
        // 最好是问后台能否改 如果后台暂时改不了
        // 确保所有.webp后缀的文件都更换为.jpg
        goods_introduce:res.goods_introduce.replace(/\.webp/g,'.jpg'),
        pics:res.pics,
      },
      iscollect
    })
    this.history()
    // console.log(res)
  },
  changecollect(){
    let {iscollect} =this.data
    let collect =wx.getStorageSync("collect")||[];
    let index=collect.findIndex(v=>v.goods_id==this.goodsinfo.goods_id)
    if(index!=-1){
      collect.splice(index,1)
      iscollect=false
      showtoast({title:'取消成功',icon:'success'})
    }else{
      collect.push(this.goodsinfo)
      iscollect=true
      showtoast({title:'收藏成功',icon:'success'})
    }
    this.setData({iscollect})
    wx.setStorageSync("collect", collect);
  },
  changepics(e){
    let newpics = this.goodsinfo.pics.map(v=>v.pics_big)
    let index = e.currentTarget.dataset.url
    // console.log(e)
    wx.previewImage({
      current: newpics[index],
      urls: newpics
    });
  },
  addcart(){
    let cart = wx.getStorageSync("cart")||[];
    let index = cart.findIndex(v=>v.goods_id==this.goodsinfo.goods_id)
    // 当这个本地存储是第一次条件数据时
    if(index==-1){
      this.goodsinfo.num=1
      this.goodsinfo.checked=true
      cart.push(this.goodsinfo)
    }else{
      cart[index].num++
    }
    wx.setStorageSync("cart", cart);
    showtoast({title: '加入成功',icon:"success",mask:true
    })
  }
})