// pages/search/index.js
import { request } from "../../request/index"
Page({
  data: {
    goods:[],
    isfocus:false,
    text:""
  },
  itmeid:-1,
  onShow: function () {

  },
  searched(e){
    let {value}=e.detail
    let {isfocus}=this.data
    console.log(value);
    if(value!=""){
      isfocus=true
    }else{
      isfocus=false
    }
    // this.getquery(value)
    clearTimeout(this.itmeid)
    this.itmeid=setTimeout(() => {
      this.getquery(value)
      this.setData({isfocus})
    }, 1000);
    
  },
  async getquery(query){
      let res = await request({
        url:"/goods/qsearch",
        data:{query}
      })
      this.setData({
        goods:res
      })
      console.log(res);
    },
    reset(){
      this.setData({
        isfocus:false,
        goods:[],
        text:""
      })
    }
})