// pages/cart/index.js
import {showModal, showtoast} from "../../request/index.js"
Page({
  data: {
    address:{},
    cart:[],
    userinfo:[],
    allchecked:false,
    edit:"编辑",
    totalprice:0,
    totalnum:0
  },
  onShow(){
    // 从本地缓存中获取数据
    let address=wx.getStorageSync("address"),
    cart=wx.getStorageSync("cart")||[],
    userinfo = wx.getStorageSync('userinfo');
    if(!userinfo){
      this.getuserinfo()
    }
      this.setData({
        address,
        userinfo
      })
      this.setcart(cart)
  },
  changechecked(scope){
    let id = scope.currentTarget.dataset.id,
    {cart} = this.data,
    index = cart.findIndex(v=>v.goods_id == id)
    cart[index].checked =! cart[index].checked
    this.setcart(cart)
  },
  chooseadd(){
    wx.chooseAddress({
      success: (result)=>{
        wx.setStorageSync("address", result);
      }
    });
  },
  setcart(cart){
    let allchecked=true,
    totalprice=0,
    totalnum=0
    cart.forEach(v=>{
      if(v.checked){
        totalprice += v.num*v.goods_price
        totalnum += v.num
      }else{
        allchecked = false
      }
    })
    allchecked=cart.length!=0?allchecked:false
    this.setData({
      cart,
      allchecked,
      totalnum,
      totalprice
    })
    wx.setStorageSync("cart",cart)
  },
  changeallchecked(){
    let {cart,allchecked}=this.data
    allchecked=!allchecked
    cart.forEach(v=>v.checked=allchecked)
    this.setcart(this.data.cart)
  },
  changenumber(scope){
    let {id,num}=scope.currentTarget.dataset,
    // console.log(id,num);
    {cart}=this.data,
    index=cart.findIndex(v=>v.goods_id==id)
    if(cart[index].num+num==0){
      return
    }else{
      cart[index].num+=num
    }
    this.setcart(cart)
  },
  changedit(){
    let edit=this.data.edit
    if(edit=="编辑"){
      edit="取消编辑"
    }else{
      edit="编辑"
    }
    this.setData({
      edit
    })
  },
  async delete(){
    let cart = wx.getStorageSync("cart")
    let newcart = cart.filter(v=>!v.checked)
    if(newcart.length==cart.length){
      showtoast({title:'您还未选中商品',icon:'error'})
      return
    }
    let res=await showModal({content:'确定要删除购物车清单吗？'})
    if(res.confirm){
      this.setcart(newcart)
      showtoast({
        title:'删除成功',
        icon:'success'
      })
      this.setData({
        edit:'编辑'
      })
    }
  },
  async pay(){
    let {address,cart} = this.data,
    check=cart.filter(v=>v.checked)
    if(!address.userName){
      await showtoast({title:"请选择您当前的收货地址"})
      return
    }else if(check==0){
      await showtoast({title:"请选择结算的商品"})
      return
    }
    wx.navigateTo({
      url: '/pages/pay/index'
    });
  },
  url(e){
    let {id} = e.currentTarget.dataset
    wx.navigateTo({
      url: '/pages/detail/index?goods_id='+id+''
    });
  },
  async getuserinfo(){
    let userinfo = await showModal({
      content:'用户信息需要您授权获取您的个人信息',
      kong:'1'
    })
    this.onShow()
  },
})