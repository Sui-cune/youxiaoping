// pages/order/index.js
import {request, showModal, login} from '../../request/index'

Page({
  orders:[],
  data: {
    tabs:[
      {
        id:0,
        value:"全部",
        active:true
      },
      {
        id:1,
        value:"待付款",
        active:false
      },
      {
        id:2,
        value:"待发货",
        active:false
      },
      {
        id:3,
        value:"退款/退货",
        active:false
      }
    ]
  },
  // onShow是不能直接获取页面的参数，需要获取小程序的页面栈
  // 页面栈-数组 长度最大是10页面
  onShow: function () {
    let token = wx.getStorageSync("token");
    if(!token){
      this.getuserinfo()
      return
    }

    let CurPages =  getCurrentPages();
    let page=CurPages[CurPages.length-1]
    // console.log(page.options);
    let {type} = page.options
    this.changeindex(type-1)
    this.getorders(type)
  },
  changeindex(index){
    let {tabs}=this.data
    tabs.forEach((v,i)=>i==index?v.active=true:v.active=false)
    this.setData({
      tabs
    })
  },
  changeselected(arr){
    // console.log(arr)
    //获取被点击项的引索
    const {index}=arr.detail
    this.changeindex(index)
    this.getorders(index+1)
  },
  async getorders(type){
    let token =wx.getStorageSync("token");
    let header = {Authorization:token}
    let res=await request({url:"/my/orders/all",header,data:{type}})
    console.log(res.orders);
    this.setData({
      orders:res.orders.map(v=>({...v,create_time_cn:(new Date(v.create_time*1000).toLocaleString())}))
    })
  },
  async getuserinfo(){
    let {code} = await login()
    let userinfo = await showModal({
      content:'用户信息需要您授权获取您的个人信息',
      kong:'1'
    })
    // console.log(userinfo);
    let {encryptedData,rawData,iv,signature}=userinfo
    let params={encryptedData,rawData,iv,signature,code}
    let tokens = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjIzLCJpYXQiOjE1NjQ3MzAwNzksImV4cCI6MTAwMTU2NDczMDA3OH0.YPt-XeLnjV-_1ITaXGY2FhxmCe4NvXuRnRB8OMCfnPo"
    // let token=await request({url:"/users/wxlogin",data:params,method:"post"})
    // console.log(token);
    wx.setStorageSync("token",tokens);
    this.onShow()
    // let res = await getaccesstoken()
    // let res2 = await getopenid()
    // console.log(res);
    // console.log(res2);
    // console.log(res3);
  }
})