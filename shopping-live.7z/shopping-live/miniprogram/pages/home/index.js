import { request } from "../../request/index.js";
Page({
  data: {
    lunbolist:[],
    catelist:[],
    floorlist:[]
  },
  onLoad: function(options){
    this.getlunbo()
    this.getcate()
    this.getfloor()
  },
  getlunbo(){
    request({
      url:"/home/swiperdata"
    }).then(res=>{
        this.setData({
          lunbolist: res
        })
        // console.log(this.lunbolist)
    })
  },
  getcate(){
    request({
      url:"/home/catitems"
    }).then(res=>{
      this.setData({
        catelist: res
      })
      // console.log(res.data.message)
    })
  },
  getfloor(){
    request({
      url:"/home/floordata"
    }).then(res=>{
      this.setData({
        floorlist:res
      })
      // console.log(res.data.message)
    })
  },
  geturl(e){
    let {baseurl} = e.currentTarget.dataset
    let url = baseurl.replace('?','/index?')
    wx.navigateTo({
      url
    });
    // console.log(url);
  }
});