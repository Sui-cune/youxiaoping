// pages/collect/index.js
import { showModal, showtoast } from '../../request/index'
Page({
  data: {
    history:[],
    allchecked:false,
    edit:"编辑"
  },
  onShow: function () {
    let history=wx.getStorageSync("history")||[];
    this.sethistory(history)
  },
  sethistory(history){
    let allchecked=true
    history.forEach(v=>{
      if(!v.checked){
        allchecked = false
      }
    })
    allchecked=(history.length!=0)?allchecked:false
    this.setData({
      history,
      allchecked
    })
    wx.setStorageSync("history",history)
  },
  async remove(){
    let history = wx.getStorageSync("history")
    let newhistory = history.filter(v=>!v.checked)
    if(this.data.edit=='编辑'){
      newhistory = []
    }else if(history.length==newhistory.length){
      showtoast({title:'您还未选中商品',icon:'error'})
      return
    }
    let res=await showModal({content:'确定要删除浏览记录吗'})
    if(res.confirm){
      this.sethistory(newhistory)
      showtoast({title:'删除成功',icon:'success'})
      this.setData({
        edit:'编辑'
      })
    }
  },
  changechecked(scope){
    let id = scope.currentTarget.dataset.id,
    {history} = this.data,
    index = history.findIndex(v=>v.goods_id == id)
    history[index].checked =! history[index].checked
    this.sethistory(history)
  },
  changeallchecked(){
    let {history,allchecked}=this.data
    allchecked=!allchecked
    history.forEach(v=>v.checked=allchecked)
    this.sethistory(history)
  },
  changetop(){
    let {edit} =this.data
    if(edit=='编辑'){
      edit='完成'
    }else{
      edit='编辑'
    }
    this.setData({edit})
  },
  gohome(){
    wx.switchTab({
      url: '/pages/home/index'
    });
  },
  godetail(e){
    let {id} =e.currentTarget.dataset
    wx.navigateTo({
      url: '/pages/detail/index?goods_id='+id+''
    });
  }
})