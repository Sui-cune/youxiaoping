// pages/collect/index.js
import {showModal, showtoast } from '../../request/index'
Page({
  data: {
    collect:[],
    tabs:[
      {
        id:0,
        value:"店铺收藏",
        active:true
      },
      {
        id:1,
        value:"商品收藏",
        active:false
      }
    ],
    default:{
      detail:{
        index:0
      }
    },
    allchecked:false,
    edit:"编辑"
  },
  onLoad(options){
    let dd= this.data.default
    dd.detail = options
    this.setData({default:dd})
    this.changeselected(this.data.default)
  },
  onShow: function () {
    let collect=wx.getStorageSync("collect")||[];
    this.setcollect(collect)
  },
  setcollect(collect){
    let allchecked=true
    collect.forEach(v=>{
      if(!v.checked){
        allchecked = false
      }
    })
    allchecked=collect.length!=0?allchecked:false
    this.setData({
      collect,
      allchecked
    })
    wx.setStorageSync("collect",collect)
  },
  changeselected(arr){
    // console.log(arr)
    //获取被点击项的引索
    let {index}=arr.detail
    let {tabs}=this.data
    tabs.forEach((v,i)=>i==index?v.active=true:v.active=false)
    this.setData({
      tabs
    })
  },
  async remove(){
    let collect = wx.getStorageSync("collect")
    let newcollect = collect.filter(v=>!v.checked)
    if(this.data.edit=='编辑'){
      newcollect = []
    }else if(collect.length==newcollect.length){
      showtoast({title:'您还未选中商品',icon:'error'})
      return
    }
    let res=await showModal({content:'确定要删除浏览记录吗'})
    if(res.confirm){
      this.setcollect(newcollect)
      showtoast({title:'删除成功',icon:'success'})
      this.setData({
        edit:'编辑'
      })
    }
  },
  changechecked(scope){
    let id = scope.currentTarget.dataset.id,
    {collect} = this.data,
    index = collect.findIndex(v=>v.goods_id == id)
    collect[index].checked =! collect[index].checked
    this.setcollect(collect)
  },
  changeallchecked(){
    let {collect,allchecked}=this.data
    allchecked=!allchecked
    collect.forEach(v=>v.checked=allchecked)
    this.setcollect(collect)
  },
  changetop(){
    let {edit} =this.data
    if(edit=='编辑'){
      edit='完成'
    }else{
      edit='编辑'
    }
    this.setData({edit})
  },
  gohome(){
    wx.switchTab({
      url: '/pages/home/index'
    });
  }
})