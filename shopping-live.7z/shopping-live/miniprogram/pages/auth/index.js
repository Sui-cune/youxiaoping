// pages/auth/index.js
Page({
  data: {

  },
  onLoad: function (options) {

  },
  onShow: function () {

  }
})