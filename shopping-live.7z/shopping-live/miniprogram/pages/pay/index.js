let app = getApp();
let cloud = request('wx-server-sdk');
import {getsessionid, getuserinfo, getuserprofile, login,  request, requestpayment, showModal, showtoast} from "../../request/index.js"


Page({
  data: {
    address:{},
    cart:[],
    userInfo:{},
    totalprice:0,
    totalnum:0,
  },
  onShow(){
    // 从本地缓存中获取数据
    let address=wx.getStorageSync("address"),
    cart=wx.getStorageSync("cart")||[]
    cart=cart.filter(v=>v.checked)
    this.setData({
      address
    })
    this.setcart(cart)
  },
  setcart(cart){
    let totalprice=0,
    totalnum=0
    cart.forEach(v=>{
        totalprice += v.num*v.goods_price
        totalnum += v.num
    })
    this.setData({
      cart,
      totalnum,
      totalprice
    })
  },
  async pay(){
    try {
      let token = wx.getStorageSync('token');
      if(!token){
        this.getuserinfo()
        return
      }
      let header={Authorization: token}
      let order_price=this.data.totalprice
      let consignee_addr = this.data.address
      let {cart}=this.data
      let goods=[]
      cart.forEach(v=>goods.push({
        goods_id:v.goods_id,
        goods_number:v.num,
        goods_price:v.goods_price
      }))

      let order_params = {order_price,consignee_addr,goods}

      let {order_number} = await request({
        url:'/my/orders/create',
        method:'POST',
        data:order_params,
        header
      })

      let {pay} = await request({
        url:'/my/orders/req_unifiedorder',
        method:'post',
        data:{order_number},
        header
      })

      await requestpayment(pay)
      let res = await request({
        url:'/my/orders/chkOrder',
        method:'post',
        data:{order_number},
        header
      })

      await showtoast({title:'支付成功'})
      //重新获取缓存中的cart,前端存储的cart已经被改变，不能直接使用
      let newcart = wx.getStorageSync('cart');
      newcart = newcart.filter(v=>!v.checked)
      wx.setStorageSync('cart', newcart);

      wx.navigateTo({
        url: '/pages/order/index'
      });
    } catch (error) {
      await showtoast({title:'支付失败'})
    }
  },
  async getuserinfo(){
    let {code} = await login()
    let userinfo = await showModal({
      content:'用户信息需要您授权获取您的个人信息',
      kong:'1'
    })

    let {encryptedData,rawData,iv,signature}=userinfo
    let params={encryptedData,rawData,iv,signature,code}
    let tokens = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjIzLCJpYXQiOjE1NjQ3MzAwNzksImV4cCI6MTAwMTU2NDczMDA3OH0.YPt-XeLnjV-_1ITaXGY2FhxmCe4NvXuRnRB8OMCfnPo"
    // let token=await request({url:"/users/wxlogin",data:params,method:"post"})
    // console.log(token);
    wx.setStorageSync("token",tokens);
    this.pay()
    // let res = await getaccesstoken()
    // let res2 = await getopenid()
    // console.log(res);
    // console.log(res2);
    // console.log(res3);
  }
})