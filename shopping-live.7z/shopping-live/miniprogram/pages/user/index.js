// pages/user/index.js
var app =  getApp();
import {getaccesstoken, getopenid, showModal, showtoast} from '../../request/index'
Page({
  data: {
    userinfo:{
      collectNums:0,
      historyNums:0
    }
  },
  onShow: function () {
    let userinfo=wx.getStorageSync("userinfo");
    let collect=wx.getStorageSync("collect")||[];
    let history=wx.getStorageSync('history')||[];
    if(!userinfo){
      this.getuserinfo()
    }
    this.setData({
      userinfo,
      collectNums:collect.length,
      historyNums:history.length
    })
  },
  async getuserinfo(){
    let userinfo = await showModal({
      content:'用户信息需要您授权获取您的个人信息',
      kong:'1'
    })
    this.onShow()
  },
  chooseadd(){
    wx.chooseAddress({
      success: (result)=>{
        wx.setStorageSync("address", result);
      }
    });
  },
  clearmemory(){
    this.setData({userinfo:[]})
    wx.clearStorageSync();
  }
})