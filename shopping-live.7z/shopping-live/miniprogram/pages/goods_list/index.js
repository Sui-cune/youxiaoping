import { request } from "../../request/index.js";
Page({
  data: {
    goodslist:[],
    tabs:[
      {
        id:0,
        value:"综合",
        active:true
      },
      {
        id:1,
        value:"销量",
        active:false
      },
      {
        id:2,
        value:"价格",
        active:false,
        order:''
      }
    ]
  },
  params:{
    query:"",
    cid:"",
    pagenum:1,
    pagesize:10
  },
  //当前页数
  totalpages:1,
  onLoad: function (options) {
    this.params.cid=options.cid||""
    this.params.query=options.query||""
    this.getgoodlist()
  },
  onPullDownRefresh(){
    this.setData({
      goodslist:[]
    })
    this.params.pagenum=1
    this.getgoodlist()
    // console.log("刷新")
  },
  onReachBottom(){
    if(this.params.pagenum>=this.totalpages){
      // console.log("没有下一页了")
      wx.showToast({
        title: '已经到最后一页了！',
      });
    }else(
      this.params.pagenum++,
      this.getgoodlist()
    )
  },
  changeselected(arr){
    //获取被点击项的引索
    const {index}=arr.detail
    let {tabs}=this.data

    if(index==2){
      if(tabs[index].order==''){
        tabs[index].order='˄'
      }else if(tabs[index].order=='˄'){
        tabs[index].order='˅'
      }else{
        tabs[index].order='˄'
      }
    }else{
      tabs[2].order=''
    }
    tabs[2].value='价格'+tabs[2].order
    tabs.forEach((v,i)=>i==index?v.active=true:v.active=false)
    this.setData({
      tabs
    })
  },
  async getgoodlist(){
    let res = await request({
      url:"/goods/search",
      data:this.params
    })
    let total = res.total
    this.totalpages = Math.ceil(total/this.params.pagesize)
    // console.log(this.totalpages)
    let params = [...this.data.goodslist,...res.goods]
    
    let {active} = this.data.tabs[2]
    if(active==true){
      this.sortbykey(params,'goods_price')
    }
    
    this.setData({
      goodslist:params
    })
    wx.stopPullDownRefresh()
    // console.log(res)
  },
  sortbykey(array,key){
    array.sort((a,b)=>{
      let x=a[key], y=b[key];
      let {tabs}=this.data
      if(tabs[2].order=='˅'){
        return ((x>y)?-1:((x>y)?1:0));
      }else{
        return ((x<y)?-1:((x<y)?1:0));
      }
      
    });
  }
})