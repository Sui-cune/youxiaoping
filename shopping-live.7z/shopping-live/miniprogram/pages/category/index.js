import { request } from "../../request/index.js";
Page({
  data: {
    leftlist:[],
    rightlist:[],
    currentindex:0,
    top:0
  },
  cates:[],
  onLoad: function (options) {
    let cates=wx.getStorageSync("cate");
    if(!cates){
      this.getcate()
    }else{
      if(Date.now()-cates.time>1000*10){
        this.getcate()
      }else{
        this.cates=cate.data
        let leftlist=this.cates.map(v=>v.cat_name)
        let rightlist = this.cates[0].children
        this.setData({
          leftlist,
          rightlist
        })
      }
    }
  },
  async getcate(){
    let res = await request({
      url:"/categories"
    })
      this.cates = res

      wx.setStorageSync("cate", {time:Date.now(),data:this.cates});

      let leftlist=this.cates.map(v=>v.cat_name)
      let rightlist = this.cates[0].children
      this.setData({
        leftlist,
        rightlist
      })
  },
  changeindex(arr){
    let {index} = arr.currentTarget.dataset
    let rightlist = this.cates[index].children
    this.setData({
      currentindex:index,
      rightlist,
      top:0
    })
    // console.log(this.currentindex)
  }
})